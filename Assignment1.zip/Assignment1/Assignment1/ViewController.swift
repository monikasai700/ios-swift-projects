//
//  ViewController.swift
//  Assignment1
//
//  Created by Sai Srujan Reddy Mekala on 9/19/16.
//  Copyright © 2016 Sai Srujan Reddy Mekala. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var PayRate: UITextField!
    @IBOutlet weak var OtRate: UITextField!
    @IBOutlet weak var Hours: UITextField!
    @IBOutlet weak var TaxRate: UITextField!
    @IBOutlet weak var OtherDeductions: UITextField!
    
    
    @IBOutlet weak var OtHourly: UITextField!
    @IBOutlet weak var OtHours: UITextField!
    @IBOutlet weak var GrossPay: UITextField!
    @IBOutlet weak var TotalTaxes: UITextField!
    @IBOutlet weak var YourPaycheck: UITextField!

    @IBAction func calc(sender: AnyObject) {
        if PayRate.text == nil
        {PayRate.text = "7.25"}
        if OtRate.text == nil
        {OtRate.text = "1.5"}
        if Hours.text == nil
        {Hours.text = "0"}
        if TaxRate.text == nil
        {TaxRate.text = "0.12"}
        if OtherDeductions.text == nil
        { OtherDeductions.text = "0"}
        
        let pr = Double(PayRate.text!)
        let or = Double(OtRate.text!)
        let hw = Int(Hours.text!)
        let tr = Double(TaxRate.text!)
        let od = Double(OtherDeductions.text!)
        
        if(pr < 0 || or < 0 || tr < 0 || od < 0)
        {
            let alert = UIAlertController(title: "Alert", message: "One of the number you entered is negative, Please enter positive numbers only", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)

        }
        
        let q1 = String(pr!*or!)
        OtHourly.text = "$\(q1)"
        
        let othr = Double(q1)
        
        if(hw < 40)
        {
            OtHours.text = "0"
            
            let q2 =  String(Double(hw!) * pr!)
            GrossPay.text = "$\(q2)"
            
            let gp = Double(q2)
            
            let q3 = String(gp! * tr!)
            TotalTaxes.text = ("$\(q3)")
            
            let tt = Double(q3)
            let q4 = String(gp! - tt! - od!)
            
            YourPaycheck.text = "$\(q4)"
        }
        else
        {
            OtHours.text = String(hw! - 40)
            let oth = Double(OtHours.text!)
            
            let q2 =  String((40 * pr!)+(oth! * othr!))
            GrossPay.text = "$\(q2)"
            
            let gp = Double(q2)
            
            let q3 = String(gp! * tr!)
            TotalTaxes.text = ("$\(q3)")
            
            let tt = Double(q3)
            let q4 = String(gp! - tt! - od!)
            
            YourPaycheck.text = "$\(q4)"
            
        }
        
     
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

}

