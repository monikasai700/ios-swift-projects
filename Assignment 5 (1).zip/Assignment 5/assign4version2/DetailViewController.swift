//
//  DetailViewController.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/8/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
//connections from storyboard to detailViewController.swift
    @IBOutlet weak var detailDescriptionLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
   @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var nicknameLabel: UILabel!

    @IBOutlet weak var partyLabel: UILabel!
    @IBOutlet weak var detailImageView: UIImageView!
    
    //an object detail item which gets description of the presidents from presidents.plist
    var detailItem: MCUpresidents? {
        //didset method caaling the configureView
        didSet {
            // Update the view.
            self.configureView()
        }
    }

    func configureView() {
        if let detail = self.detailItem {
            if let label = self.nameLabel {
                label.text = detail.name
                //getting the name from mcupresidents and passing it to label
            }
            
            if let imageView = self.detailImageView {
                ImageProvider.sharedInstance.imageWithURLString(detail.url) {
                    (image) in
                    imageView.image = image
                }
            }

                      if let label = self.nicknameLabel
           {
            label.text = detail.nickName
            }
            if let label = self.partyLabel
                //getting the nick name from mcupresidents and passing it to label
            {
                label.text = detail.politicalParty
            }
            if let label = self.dateLabel
            {
                label.text = "(" + detail.startDate + " to " + detail.endDate + ")"
                //getting the startdate and enddate from mcupresidents and passing it to label
            }
           if let label = self.countLabel
           {
           let numb = detail.number
            
            label.text = numb.ordinal + " President of the United States"
            
            /*if(numb % 10 == 1)
            {
            label.text = String(numb) + "st " + "President of the United states "
                //getting the number from mcupresidents and passing it to label along with "st"
            }
           else if(numb % 10 == 2)
            {
                label.text = String(numb) + "nd " + "President of the United states "
                //getting the number from mcupresidents and passing it to label along with "nd"
            }
           else if(numb % 10 == 3)
            {
                label.text = String(numb) + "rd " + "President of the United states "
                //getting the number from mcupresidents and passing it to label along with "rd"
            }
           
            else {
                label.text = String(numb) + "th " + "President of the United states "
                //getting the number from mcupresidents and pasing it to label along with "th"
            } */
            }
    }
       
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

