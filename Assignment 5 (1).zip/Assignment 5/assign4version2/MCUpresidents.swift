//
//  MCUpresidents.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/8/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import Foundation
class MCUpresidents{
    
var name = "" //declaring the variable for name
var number = 0 //declaring the vaiable for number
var startDate = "" //declaring the vaiable for start date
var endDate = "" //declaring the vaiable for end date
var nickName = ""  //declaring the vaiable for nickname
var politicalParty = "" //declaring the vaiable for political party
//initialing the variables
var url = ""
    init(name: String, number : Int, startDate: String, endDate: String, nickName: String, politicalParty: String, url: String)
{
    self.name = name
    self.number = number
    self.startDate = startDate
    self.endDate = endDate
    self.nickName = nickName
    self.politicalParty = politicalParty
    self.url = url
}
    
}