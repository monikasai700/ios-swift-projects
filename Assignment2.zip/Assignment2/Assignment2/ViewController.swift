//
//  ViewController.swift
//  Assignment2
//
//  Created by Sai Mounika Tadaka on 10/6/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 // declaration of variables
    @IBOutlet weak var slider1: UISlider!
    @IBOutlet weak var slider2: UISlider!
    @IBOutlet weak var label1slider: UILabel!
    @IBOutlet weak var label2slider: UILabel!
    
    @IBOutlet weak var lab_slider1: UISlider!
    
    @IBOutlet weak var lab_slider2: UILabel!
    
    @IBOutlet weak var BillAmount: UITextField!
    
    @IBOutlet weak var print1: UILabel!
    @IBOutlet weak var print2: UILabel!
    
    @IBOutlet weak var labelAlert: UILabel!
    
    /*func valueChanged(textField: UITextField)
    {
        if let textField = BillAmount
        {
        textField.resignFirstResponder()
           
            print1.text = "$" + String(format: "%.2f", tipAmount)
            print2.text = "$" + String(format: "%.2f", sizeAmount)
        }
    }  */
    //assigning a constant property
    
    var tipAmount = 0.00
    var sizeAmount = 0.00
    var cur_1 = 0.00
    
    var bill_amount = 0.00
        {
        didSet {
            configureView() // messgaes from model to the controller using didset method and configureView
        }
    }
     func configureView()
    {
        /*valueChanged(BillAmount)*/
        //setting initial loading properties
        label1slider.textColor = UIColor.whiteColor()
        label2slider.textColor = UIColor.whiteColor()
        print1.textColor = UIColor.whiteColor()
        print2.textColor = UIColor.whiteColor()
        // self.view.endEditing(true)
      //  print2.text = "$" + String(format: "%.2f", sizeAmount)
        
        /*  if(bill_amount>0)
        {
            tipAmount = (bill_amount*cur_1/100)+bill_amount
            print1.text = "$" + String(format: "%.2f", tipAmount)
            //print2.text = "$" + String(format: "%.2f", sizeAmount)
        
        } */
        
        
    }
    //messages from view to controller
 @IBAction func done(sender: AnyObject) {
        
        let x = BillAmount.text!
        if !x.isEmpty
        {
            if let temp = Double(x)
            {
                //labelAlert.text = "Your bill amount is \(temp) \nPlease select tip percentage and size"
                alert("your bill amount is \(temp) now please select tip percentage and size of party") //printing message to enter tip percentage and size when user doesnot enter them after bill amount is entered
            }
        
        else
        {
            alert("please enter valid bill amount") //call to alert function which displays an alert message when user enters invalid characters
        }
            
        }
}
    //alert function to give an alert message when user enters invalid data
   func alert(errorMessage: String)
    {
        let alertController = UIAlertController(title:"Hello!!" ,message: errorMessage,preferredStyle: .Alert)
        let cancelAction = UIAlertAction(title: "ok", style: .Cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.presentViewController(alertController,animated: true, completion: nil)
    }
    /***** this function does the required calculation for tip percentage when the tip percentage slider is moved *****/
 @IBAction func sliderAction1(sender: UISlider) {
        
        if((BillAmount.text! as NSString).doubleValue > 0)
        {
            bill_amount = (BillAmount.text! as NSString).doubleValue //converting string to double
       
        }
        
        
        let currentValue = Int(sender.value) * 5 //current value is the slider value when moved in multiples of 5
       
       if(bill_amount > 0)
        {
             tipAmount  = (bill_amount*Double(currentValue)/100)+bill_amount  //calculating tip amount
            //tipAmount = (temp as NSString).doubleValue
print1.text = "$"+String(format:"%.2f",tipAmount) // printing the tip amount value in the label beside slider limiting the decimal values to two places after the decimal point
        }
        
        let string1 = "%"
        
        label1slider.text = "\(currentValue)" + string1
    }
    /***** this function does the required calculation for share of bill amount when size of party selected this is done when slider size of party is moved *****/
    @IBAction  func sliderAction2(sender: UISlider) {
        let currentValue = Int(sender.value)
        label2slider.text = "\(currentValue)"
    
        sizeAmount = tipAmount/Double(currentValue)  //calculating sizeamount using tip amount from sliderAction1 by declaring tip amount globally
        print2.text = "$" + String(format: "%.2f", sizeAmount)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       // BillAmount.text = String(format: "%.2f", arguments:[])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    // MARK: UIResponder methods
    
    //allowing the user to signal they are done entering
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
        
        
    }

}
