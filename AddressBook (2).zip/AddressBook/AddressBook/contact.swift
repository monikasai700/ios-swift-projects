//
//  contact.swift
//  AddressBook
//
//  Created by Sai Mounika Tadaka on 11/18/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class contact: NSObject,NSCoding{
    //adding attributes
    var firstName: String
    var lastName: String
    var emailAddress: String
    //adding initializers
    override init() {
        firstName = "Monika"
        lastName = "Tadaka"
        emailAddress = "monika123@gmail.com"
        
    }
    init(firstName fn:String,lastName ln:String,emailAddress ea:String) {
     firstName = fn
        lastName = ln
        emailAddress = ea
        
    }
    //adding functions
    
    required init?(coder aDecoder: NSCoder) {
        
       firstName =  aDecoder.decodeObjectForKey("FirstName") as! String
        lastName = aDecoder.decodeObjectForKey("LastName") as! String
        emailAddress = aDecoder.decodeObjectForKey("EmailAddress") as! String
    }
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(firstName,forKey:"FirstName")
        aCoder.encodeObject(lastName,forKey: "LastName")
        aCoder.encodeObject(emailAddress,forKey: "EmailAddress")
    }

}
