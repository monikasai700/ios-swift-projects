//
//  ContactsDataSource.swift
//  AddressBook
//
//  Created by Sai Mounika Tadaka on 11/21/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class ContactsDataSource: UITableViewCell {
//Attribute list
    let contacts = NSMutableArray()
    //defing initializers
    override init(){
        //creating a contact
        let sampelContact = contact()
        contacts.addObject(sampelContact)
    }
    
    
}
