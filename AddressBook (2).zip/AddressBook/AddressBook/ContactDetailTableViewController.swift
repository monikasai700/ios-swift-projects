//
//  ContactDetailTableViewController.swift
//  AddressBook
//
//  Created by Sai Mounika Tadaka on 11/21/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class ContactDetailTableViewController: UITableViewController {

    @IBOutlet weak var lblEmailAddress: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var lblFirstName: UILabel!
    var Contact : contact!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    lblFirstName.text = Contact.firstName
    lblLastName.text = Contact.lastName
    lblEmailAddress.text = Contact.emailAddress
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
}
