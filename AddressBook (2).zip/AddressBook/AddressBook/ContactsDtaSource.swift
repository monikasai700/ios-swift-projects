//
//  ContactsDtaSource.swift
//  AddressBook
//
//  Created by Sai Mounika Tadaka on 11/21/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class ContactsDtaSource: NSObject {
    
   //attribute list
    let contacts = NSMutableArray()
    //defing initializers
    override init(){
        //creating a contact
        //let sampleContact = contact()
        //contacts.addObject(sampleContact)
        super.init()
        self.getContacts()
    }
//Functions
    func countOfContacts() -> Int{
        return contacts.count
    }
    
    func contactAtIndex(contactIndex index:Int) -> contact{
        let tempContact = contacts.objectAtIndex(index) as! contact
        return tempContact
    }

    func addContact(contact c:contact){
        contacts.addObject(c)
        saveContacts()
    }
    func deleteContactAtIndex(index: Int)
    {
        contacts.removeObjectAtIndex(index)
        saveContacts()
    }

    func moveContacts(fromContactIndex fromIndex:Int, toContactIndex toIndex: Int){
        //retrieving the contact that will be move from
        let fromContact = contacts.objectAtIndex(fromIndex) as! contact
        let  toContact = contacts.objectAtIndex(toIndex) as! contact
        //replace contacts in array
        contacts.replaceObjectAtIndex(fromIndex, withObject: toContact)
        
        contacts.replaceObjectAtIndex(toIndex, withObject: fromContact)
        //save contact
        saveContacts()
    }
    func getFileURLPath() -> NSURL{
        //getting a reference to file
        let fileManager = NSFileManager.defaultManager()
        //getting a  reference to directory
        let appSupportDirectory = try! fileManager.URLForDirectory(NSSearchPathDirectory.ApplicationSupportDirectory, inDomain: NSSearchPathDomainMask.UserDomainMask, appropriateForURL: nil, create: true)
        
        //adding file to directory
        let fileURL = appSupportDirectory.URLByAppendingPathComponent("addressBook.data")
        //return the file url
        return fileURL
        
    }
    func saveContacts()
    {
        //retrieve the location of the file
        let filePath = getFileURLPath().path!

        //save the contacts
        NSKeyedArchiver.archiveRootObject(contacts, toFile: filePath)
    }
    func getContacts()
    {
        //retrieve the location of file
        let filePath = getFileURLPath().path!
        //opening file and load contents into array only when file exists
        let fileManager = NSFileManager.defaultManager()
        if (fileManager.fileExistsAtPath(filePath)){
            let contentsOfFile = NSKeyedUnarchiver.unarchiveObjectWithFile(filePath) as! NSArray
            contacts.addObjectsFromArray(contentsOfFile as [AnyObject])
        }
    }
}
