//
//  extraTableViewController.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/10/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class extraTableViewController: UITableViewController,UITextFieldDelegate{
let datePicker: UIDatePicker! = UIDatePicker()
    
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var startDate: UITextField!
    @IBOutlet weak var endDate: UITextField!
 
    @IBOutlet weak var nickNameText: UITextField!
    @IBOutlet weak var polPartySeg: UISegmentedControl!
    var character: MCUpresidents?
    
    
    
    func setUpDatePicker() {
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 0, height: 44))
        let doneButton = UIBarButtonItem(title: "Select", style: UIBarButtonItemStyle.Done, target: self, action: #selector(extraTableViewController.selectItem))
        let space = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: nil, action: nil)
        
        toolBar.setItems([space, doneButton], animated: false)
        //startDatePicker = UIDatePicker()
        startDate.inputAccessoryView = toolBar
        startDate.inputView = datePicker
        
        endDate.inputAccessoryView = toolBar
        endDate.inputView = datePicker
    }
    
    func selectItem() {
        startDate.endEditing(true)
        endDate.endEditing(true)
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.section == 0 {
            nameText.becomeFirstResponder()
        }
        if indexPath.section == 2 {
            startDate.becomeFirstResponder()
        }
        if indexPath.section == 3 {
            endDate.becomeFirstResponder()
        }
        if indexPath.section == 4 {
            nickNameText.becomeFirstResponder()
        }
        if indexPath.section == 5 {
            polPartySeg.becomeFirstResponder()
        }
        
    }
    
    @IBAction func saveButton(sender: UIBarButtonItem) {
        let name = nameText.text!
        if !name.isEmpty {
            print("successful!!")
        }
        else
        {
            let alertController = UIAlertController(title: "Error", message: "Please enter name", preferredStyle: .Alert)
            let cancelAction = UIAlertAction(title: "OK", style: .Cancel, handler: nil)
            alertController.addAction(cancelAction)
            self.presentViewController(alertController, animated: true, completion: nil)
        }
    }
    // MARK: UIResponder methods
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }
    
    // MARK: UITextFieldDelegate methods
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        setUpDatePicker()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        let number = 30
        
        if segue.identifier == "SaveCharacter" {
            character = MCUpresidents(name: nameText.text!, number: number, startDate: startDate.text!, endDate: endDate.text!, nickName: nickNameText.text!, politicalParty: nickNameText.text!)
        }
    }
    
   
    
    
}
