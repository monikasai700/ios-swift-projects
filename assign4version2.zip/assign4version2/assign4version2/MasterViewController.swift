//
//  MasterViewController.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/8/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController, UISearchControllerDelegate, UISearchBarDelegate, UISearchResultsUpdating{
    let searchController = UISearchController(searchResultsController: nil)
    var detailViewController: DetailViewController? = nil
    var objects = [MCUpresidents]()
    var filteredObjects = [MCUpresidents]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.leftBarButtonItem = self.editButtonItem()

        //let addButton = UIBarButtonItem(barButtonSystemItem: .Add, target: self, action: #selector(insertNewObject(_:)))
       // self.navigationItem.rightBarButtonItem = addButton
        if let split = self.splitViewController {
            let controllers = split.viewControllers
            self.detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
        
      readPropertyList()
    
        // Create search controller and set up search bar and scope bar
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.delegate = self
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchBar.scopeButtonTitles = ["All", "Democrat", "Republican", "Whig"]
        searchController.searchBar.delegate = self
        searchController.searchBar.sizeToFit()

    
    
    
    
    
    }

    override func viewWillAppear(animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.collapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*func insertNewObject(sender: AnyObject) {
       // objects.insert(NSDate(), atIndex: 0)
        let indexPath = NSIndexPath(forRow: 0, inSection: 0)
        self.tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
    }*/

    // MARK: - Segues

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let object = objects[indexPath.row]
                let controller = (segue.destinationViewController as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = object
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    func readPropertyList() {
        let plistURL = NSBundle.mainBundle().URLForResource("presidents", withExtension: ".plist")
        let array = NSArray(contentsOfURL: plistURL!) as! [AnyObject]
        
        for dictionary in array {
            let name = dictionary["Name"] as! String
            //let realName = dictionary["Number"] as! Int
            let startDate = dictionary["Start Date"] as! String
            let endDate = dictionary["End Date"] as! String
            let nickName = dictionary["Nickname"] as! String
            let politicalParty = dictionary["Political Party"] as! String
            let numb = dictionary["Number"] as! Int
            
            objects.append(MCUpresidents(name:  name, number : numb, startDate: startDate, endDate: endDate, nickName: nickName, politicalParty: politicalParty))
        }
        
        objects.sortInPlace {
            return $0.number < $1.number
        }
    }

    
    
    // MARK: - Table View

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchController.active && searchController.searchBar.text != ""
        {
      return filteredObjects.count
        }
        return objects.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
      let character: MCUpresidents
        if searchController.active && searchController.searchBar.text != ""
        {
            character = filteredObjects[indexPath.row]
        }
        else
        {
            character = objects[indexPath.row]
        }
        // let object = objects[indexPath.row] as! NSDate
     //   character = objects[indexPath.row]
        cell.textLabel!.text = character.name
        cell.detailTextLabel!.text = character.politicalParty
        return cell
    }

    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            objects.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }

    func filterContentForSearchText(searchText: String, scope: String = "All") {
    filteredObjects = objects.filter { character in
    let categoryMatch = ((scope == "All") || ( character.politicalParty == scope))
    return categoryMatch && character.name.lowercaseString.containsString(searchText.lowercaseString)
    }
    
    tableView.reloadData()
    }
    
    func updateSearchResultsForSearchController(searchController: UISearchController) {
        let searchBar = searchController.searchBar
        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
        filterContentForSearchText(searchController.searchBar.text!, scope: scope)
    }
    
    func searchBar(searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        filterContentForSearchText(searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
    }
    
    @IBAction func unwindToSave(segue: UIStoryboardSegue) {
        print("Save")
    }
    
    @IBAction func unwindToCancel(segue: UIStoryboardSegue) {
        print("Cancel")
    }
    
   /* override func shouldAutorotate() -> Bool {
        
        
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return [UIInterfaceOrientationMask.Portrait ]
    }*/
}

