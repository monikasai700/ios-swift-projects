//
//  upsideDown.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/10/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

extension UINavigationController {
    override public func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return .All
    }
}

extension UISplitViewController {
    override public func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return .All
    }
}

extension UITabBarController {
    override public func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return .All
    }
}