//
//  DetailViewController.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/8/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
   @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var nicknameLabel: UILabel!

   // @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var partyLabel: UILabel!
    var detailItem: MCUpresidents? {
        didSet {
            // Update the view.
            self.configureView()
        }
    }

    func configureView() {
        if let detail = self.detailItem {
            if let label = self.nameLabel {
                label.text = detail.name
            }
                      if let label = self.nicknameLabel
           {
            label.text = detail.nickName
            }
            if let label = self.partyLabel
            {
                label.text = detail.politicalParty
            }
            if let label = self.dateLabel
            {
                label.text = "(" + detail.startDate + " to " + detail.endDate + ")"
            }
           if let label = self.countLabel
           {
           let numb = detail.number
            if(numb % 10 == 1)
            {
            label.text = String(numb) + "st " + "President of the United states "
            }
           else if(numb % 10 == 2)
            {
                label.text = String(numb) + "nd " + "President of the United states "
            }
           else if(numb % 10 == 3)
            {
                label.text = String(numb) + "rd " + "President of the United states "
            }
           
            else {
                label.text = String(numb) + "th " + "President of the United states "
            }
            }
    }
        
        
        // Update the user interface for the detail item.
       
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

