//
//  MCUpresidents.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/8/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import Foundation
class MCUpresidents{
var name = ""
var number = 0
var startDate = ""
var endDate = ""
var nickName = ""
var politicalParty = ""

    init(name: String, number : Int, startDate: String, endDate: String, nickName: String, politicalParty: String)
{
    self.name = name
    self.number = number
    self.startDate = startDate
    self.endDate = endDate
    self.nickName = nickName
    self.politicalParty = politicalParty
   
}
    
}