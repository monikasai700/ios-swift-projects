//
//  SecondViewController.swift
//  assign3
//
//  Created by Sai Mounika Tadaka on 10/24/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController ,UIPickerViewDataSource,UIPickerViewDelegate{
    
    var pickerData = [String]()
    var i = 0
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let itemSelected = pickerData[row]
        let formatter = NSNumberFormatter()
        formatter.numberStyle = .DecimalStyle
        formatter.maximumFractionDigits = 2
        var comp : Double = 0.0
        var fin : Double  = 0.0
        let temp2 = "\u{00B0}"
        if i == 0
        {
            fin = (itemSelected as NSString).doubleValue
            comp = (fin - 32) / 1.8
            output.text = "\(formatter.stringFromNumber(comp)!) \(temp2) C"
        }
        if i == 1
        {
            comp = (itemSelected as NSString).doubleValue
            fin = (comp * 1.8) + 32
            output.text = "\(formatter.stringFromNumber(fin)!) \(temp2) F"
        }
    }
    override func viewDidLoad() {
         let temp2 = "\u{00B0}"
        super.viewDidLoad()
        controller.setTitle("\(temp2)F->\(temp2)C", forSegmentAtIndex: 0)
        controller.setTitle("\(temp2)C->\(temp2)F", forSegmentAtIndex: 1)
        // Do any additional setup after loading the view, typically from a nib.
               self.singlePicker.delegate = self
        //self.singlePicker.dataSource = self
     
        reloadAllComponents()
    }
    func reloadAllComponents()
    {
        let temp2 = "\u{00B0}"
        if i == 0
        {
            
            pickerData.removeAll()
            for i in -129...134 {
                pickerData.append( String(i) + "\(temp2)" + "F")
            }
            /* for var i = -129; i < 135; i++ {
             pickerData.append( String(i))
             
             }*/
        }
        if i == 1{
            pickerData.removeAll()
            for i in -90...57
            {
                pickerData.append(String(i) + "\(temp2)" + "C")
            }
            
        }

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // @IBOutlet weak var singlePicker: UIPickerView!
    
    @IBOutlet weak var singlePicker: UIPickerView!
    
    // @IBOutlet weak var output: UILabel!
    
    @IBOutlet weak var output: UILabel!
    // @IBOutlet weak var controller: UISegmentedControl!
    
    @IBOutlet weak var controller: UISegmentedControl!
    // @IBAction func controllerAction(sender: AnyObject)
    
    @IBAction func controllerAction(sender: AnyObject)
    {
        
        if controller.selectedSegmentIndex == 0 {
            i = 0
            viewDidLoad()
            
        }
        
        
        if controller.selectedSegmentIndex == 1{
            i = 1
            viewDidLoad()
        }
        
    }
    
    
    
    
}

