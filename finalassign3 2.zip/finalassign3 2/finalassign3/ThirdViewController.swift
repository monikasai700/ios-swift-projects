//
//  ThirdViewController.swift
//  finalassign3
//
//  Created by Sai Mounika Tadaka on 10/25/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController,UIPickerViewDelegate{

    
    @IBOutlet weak var datePicker1: UIDatePicker!
    @IBOutlet weak var DatePicker2: UIDatePicker!
    @IBOutlet weak var outputLabel: UILabel!
   
   // var pickerData = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker1.datePickerMode = UIDatePickerMode.Date
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        let selectedDate = dateFormatter.stringFromDate(datePicker1.date)        // Do any additional setup after loading the view.
        outputLabel.text = selectedDate
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    @IBAction func buttonPressed(sender: AnyObject)
    {
      // var minDate = datePicker1.date
      //  minDate = NSDate
        datePicker1.datePickerMode = UIDatePickerMode.Date
        DatePicker2.datePickerMode = UIDatePickerMode.Date
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd MM yyyy"
      let difference = (DatePicker2.date).timeIntervalSinceDate(datePicker1.date)
        
       
        let another = Int(round(difference/86400.0))
        
       outputLabel.text = String(another)
    }
  

}
