//
//  FirstViewController.swift
//  finalassign3
//
//  Created by Sai Mounika Tadaka on 10/24/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit


class FirstViewController: UIViewController{
var myTimer: NSTimer?
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var printLabel: UILabel!
  //  var afterRemainder = 0.0
    //var remainder = 0.0
    var temp = 0
    //var dated = NSTimer()
    
    func timeFormatted(totalSeconds: Int) -> String {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        let hours: Int = totalSeconds / 3600
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }

 var buttonPress = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        let dateFormatter = NSDateFormatter()
        dateFormatter.locale = NSLocale(localeIdentifier:"en_US")
        dateFormatter.dateFormat =  "HH:mm:ss"
        
        let date = dateFormatter.dateFromString("00:01:00")
        datePicker.date = date!
        printLabel.text = (dateFormatter.stringFromDate(date!))
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func start(sender: AnyObject) {
      
         temp = Int(self.datePicker.countDownDuration)

        myTimer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(decrementClock), userInfo: nil, repeats: true)
        
    }
    func decrementClock(timer: NSTimer)
{
    
   temp-=1
    
    let formatted = timeFormatted(temp)
 
    //printLabel.text = String(temp)
    
    printLabel.text = formatted
    
    if(temp==0)
    {
        myTimer?.invalidate()
    }
   
}
    @IBAction func pause(sender: AnyObject) {
        myTimer!.invalidate()
        buttonPress += 1
        if(buttonPress%2==0)
        {
    myTimer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(decrementClock), userInfo: nil, repeats: true)
        }
    }
  
    @IBAction func stop(sender: AnyObject) {
       myTimer!.invalidate()
   temp = 0
        let formatted = timeFormatted(temp)
        printLabel.text = formatted
    }
   
}

