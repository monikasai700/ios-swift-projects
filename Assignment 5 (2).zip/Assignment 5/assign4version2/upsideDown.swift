//
//  upsideDown.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/10/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit
//upside down orientation for navigation controller
extension UINavigationController {
    override public func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return .All
    }
}
//upside down orientation for splitview controller
extension UISplitViewController {
    override public func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return .All
    }
}
//upside down orientation for tab bar controller
extension UITabBarController {
    override public func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return .All
    }
}