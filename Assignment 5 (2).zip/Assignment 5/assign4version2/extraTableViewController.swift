//
//  extraTableViewController.swift
//  assign4version2
//
//  Created by Sai Mounika Tadaka on 11/10/16.
//  Copyright © 2016 Sai Mounika Tadaka. All rights reserved.
//

import UIKit

class extraTableViewController: UITableViewController,UITextFieldDelegate{
let datePicker: UIDatePicker! = UIDatePicker()
    //outlets for textfields and segmented control
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var startDate: UITextField!
    @IBOutlet weak var endDate: UITextField!
    @IBOutlet weak var nickNameText: UITextField!
    @IBOutlet weak var polPartySeg: UISegmentedControl!
    //declaring object character getting the presidents data form MCUPresidents
    var character: MCUpresidents?

    //setupdate picker function creates a datepicker for the start date fields
    func setUpDatePicker() {
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 0, height: 44)) //creating a toolbar with required size
        //select button which appears with the date picker to select the date
        let doneButton = UIBarButtonItem(title: "Select", style: UIBarButtonItemStyle.Done, target: self, action: #selector(extraTableViewController.selectItem))
        //giving the space constraints for the picker
        let space = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: nil, action: nil)
        //setting the above space and done button items
        toolBar.setItems([space, doneButton], animated: false)
        //setting the datepicker for start date
        startDate.inputAccessoryView = toolBar
        startDate.inputView = datePicker
       
        endDate.inputAccessoryView = toolBar
        endDate.inputView = datePicker
        let DatePicker = UIDatePicker()
        DatePicker.datePickerMode = .Date
        DatePicker.addTarget(self, action: #selector(startdateselect),forControlEvents: .ValueChanged)
        
    
        startDate.inputView = DatePicker
        startDate.inputAccessoryView = toolBar

        
    }
    
    //setupdate picker function creates a datepicker for the end date fields
    func setupdatepicker2()
    {
        
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 0, height: 44)) //creating a toolbar with required size
        //select button which appears with the date picker to select the date
        let doneButton = UIBarButtonItem(title: "Select", style: UIBarButtonItemStyle.Done, target: self, action: #selector(extraTableViewController.selectItem))
        //giving the space constraints for the picker
        let space = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.FlexibleSpace, target: nil, action: nil)
        //setting the above space and done button items
        toolBar.setItems([space, doneButton], animated: false)
        //setting the datepicker for start date
        startDate.inputAccessoryView = toolBar
        startDate.inputView = datePicker
        
        endDate.inputAccessoryView = toolBar
        endDate.inputView = datePicker
        let DatePicker = UIDatePicker()
        DatePicker.datePickerMode = .Date
        DatePicker.addTarget(self, action: #selector(startdateselect),forControlEvents: .ValueChanged)
        
        endDate.inputView = DatePicker
        endDate.inputAccessoryView = toolBar

    }
    func startdateselect()
    {
        datePicker.datePickerMode = UIDatePickerMode.Date
        let dateFormatter = NSDateFormatter()
        //gives the date format in dd:mmm:yyyy
        dateFormatter.dateFormat = "dd MMM yyyy"
        let selectedDate = dateFormatter.stringFromDate(datePicker.date)        // Do any additional setup after loading the view.
        //prints the selected date format in the label from pickern 1
        startDate.text = selectedDate
        //let DatePicker = UIDatePicker()
    }
    func enddateselect()
    {
        datePicker.datePickerMode = UIDatePickerMode.Date
        let dateFormatter = NSDateFormatter()
        //gives the date format in dd:mmm:yyyy
        dateFormatter.dateFormat = "dd MMM yyyy"
        let selectedDate = dateFormatter.stringFromDate(datePicker.date)        // Do any additional setup after loading the view.
        //prints the selected date format in the label from pickern 1
        endDate.text = selectedDate
        //let DatePicker = UIDatePicker()
    }
    //selects the item from picker
    func selectItem() {
        startDate.endEditing(true)
        endDate.endEditing(true)
    }
    //Notifies that it is about to become first responder in its window.
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if indexPath.section == 0 {
            nameText.becomeFirstResponder()
        }
        if indexPath.section == 2 {
            startDate.becomeFirstResponder()
        }
        if indexPath.section == 3 {
            endDate.becomeFirstResponder()
        }
        if indexPath.section == 4 {
            nickNameText.becomeFirstResponder()
        }
        if indexPath.section == 5 {
            polPartySeg.becomeFirstResponder()
        }
        
    }
    
   //creating the alert message when the data is not entered in the required text fields
    @IBAction func saveButton(sender: UIBarButtonItem) {
        let name = nameText.text!
        if !name.isEmpty {
            print("successful!!")
        }
        else
        {
            let alertController = UIAlertController(title: "Error", message: "Please enter name", preferredStyle: .Alert)
            let cancelAction = UIAlertAction(title: "OK", style: .Cancel, handler: nil)
            alertController.addAction(cancelAction)
            self.presentViewController(alertController, animated: true, completion: nil)
        }
    }
    // MARK: UIResponder methods
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }
    
    // MARK: UITextFieldDelegate methods
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       //calling the setUpDatePicker method when loaded
        
        setUpDatePicker()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
        
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject!) -> Bool {
        if identifier == "showDetail" {
            
            if (nameText.text!.isEmpty) {
                
                message("enter name")
                return false
            }
                
            else {
                return true
            }
        }
        
        // by default, transition
        return true
    }
    
    func message(message:String)
    {
        let alertController = UIAlertController(title: "Error", message: "Please enter name", preferredStyle: .Alert)
        let cancelAction = UIAlertAction(title: "OK", style: .Cancel, handler: nil)
        alertController.addAction(cancelAction)
          dispatch_async(dispatch_get_main_queue())
            {
        self.presentViewController(alertController, animated: true, completion: nil)
        }
      

        
    }
}
